پروژه اندرویدی TelePrompt Pro

این بسته، سورس آماده باز شدن در Android Studio است؛ فایل APK از قبل داخل آن ساخته نشده است.

ساخت APK:
1) Android Studio را نصب و اجرا کنید.
2) از File > Open پوشه TelePromptPro را انتخاب کنید.
3) صبر کنید Gradle Sync تمام شود و در صورت درخواست، SDK Platform 35 و Android Gradle Plugin را نصب کنید.
4) از منوی Build گزینه Build Bundle(s) / APK(s) > Build APK(s) را بزنید.
5) فایل خروجی معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk قرار می‌گیرد.

نکته:
- برنامه به صورت WebView بسته‌بندی شده و محتوای اصلی داخل app/src/main/assets است.
- دسترسی میکروفون درخواست می‌شود؛ تشخیص گفتار به پشتیبانی WebView/نسخه اندروید و سرویس گفتار دستگاه وابسته است و ممکن است در بعضی گوشی‌ها کار نکند.
- برای اولین ساخت، اینترنت لازم است تا Android Studio وابستگی‌ها و Android SDK را دریافت کند.
